using SHA
"""
An individual block structure
"""
type Block
    index::Int
    timestamp::DateTime
    data::String
    previous_hash::String
    nonce::UInt32
end

"""
Add another block to the chain.
"""
function next_block(new_index, tail_hash; dificult = 1)
    block = Block(new_index, Dates.now(), string("This is block ",new_index), tail_hash, 0)
    hash = sha2_256(string(block))
    zerosv = zeros(UInt8,dificult)
    while hash[1:dificult] != zerosv
        block.nonce += 1
        hash = sha2_256(string(block))
    end
    return block, bytes2hex(hash)
end

# Create the special first block or the head of the blockchain.
tail_index = 0
block, tail_hash = next_block(tail_index,"0")
Blockchain = [block]

println("Genesis Block : 1")
println("Hash :", tail_hash)

# Size of the blockchain
Blockchain_limit = 13

# To make addition of blocks to the blockchain non-arbitary (unlike here),
# a proof of work task is required.
for tail = 1:Blockchain_limit
    tail_index += 1
    block, tail_hash = next_block(tail_index, tail_hash)
    # Link the new block to the chain
    push!(Blockchain, block)
    # The details of the block
    println("Block : $(tail+1)")
    println("Hash :", tail_hash)
end


# Test hash dificult
max_dif = 5
times = Array(Float64,max_dif)
for i = 1:max_dif
    tic()
    block, tail_hash = next_block(tail_index,"0"; dificult = i)
    times[i] =  toq()
    println("Tempo $(i) = $(times[i])")
end
